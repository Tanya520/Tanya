﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form3
    Inherits System.Windows.Forms.Form

    'Форма переопределяет dispose для очистки списка компонентов.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Является обязательной для конструктора форм Windows Forms
    Private components As System.ComponentModel.IContainer

    'Примечание: следующая процедура является обязательной для конструктора форм Windows Forms
    'Для ее изменения используйте конструктор форм Windows Form.  
    'Не изменяйте ее в редакторе исходного кода.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Gerasimova_FITDataSet = New Gerasimova_FIT.Gerasimova_FITDataSet()
        Me.УслугиBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.УслугиTableAdapter = New Gerasimova_FIT.Gerasimova_FITDataSetTableAdapters.УслугиTableAdapter()
        Me.TableAdapterManager = New Gerasimova_FIT.Gerasimova_FITDataSetTableAdapters.TableAdapterManager()
        Me.УслугиDataGridView = New System.Windows.Forms.DataGridView()
        Me.ОтделенияBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ОтделенияTableAdapter = New Gerasimova_FIT.Gerasimova_FITDataSetTableAdapters.ОтделенияTableAdapter()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Стоимость = New System.Windows.Forms.DataGridViewTextBoxColumn()
        CType(Me.Gerasimova_FITDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.УслугиBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.УслугиDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ОтделенияBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Button2
        '
        Me.Button2.BackColor = System.Drawing.Color.DarkKhaki
        Me.Button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Button2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.Button2.Location = New System.Drawing.Point(553, 488)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(145, 61)
        Me.Button2.TabIndex = 16
        Me.Button2.Text = "Назад"
        Me.Button2.UseVisualStyleBackColor = False
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("Candara", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.Label4.Location = New System.Drawing.Point(506, 87)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(192, 33)
        Me.Label4.TabIndex = 15
        Me.Label4.Text = "Перечень услуг"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Candara", 20.25!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        Me.Label1.Location = New System.Drawing.Point(18, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(242, 33)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "Фитнесс - клуб F.I.T"
        '
        'Gerasimova_FITDataSet
        '
        Me.Gerasimova_FITDataSet.DataSetName = "Gerasimova_FITDataSet"
        Me.Gerasimova_FITDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'УслугиBindingSource
        '
        Me.УслугиBindingSource.DataMember = "Услуги"
        Me.УслугиBindingSource.DataSource = Me.Gerasimova_FITDataSet
        '
        'УслугиTableAdapter
        '
        Me.УслугиTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.UpdateOrder = Gerasimova_FIT.Gerasimova_FITDataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        Me.TableAdapterManager.КлиентыTableAdapter = Nothing
        Me.TableAdapterManager.ОтделенияTableAdapter = Me.ОтделенияTableAdapter
        Me.TableAdapterManager.УслугиTableAdapter = Me.УслугиTableAdapter
        '
        'УслугиDataGridView
        '
        Me.УслугиDataGridView.AutoGenerateColumns = False
        Me.УслугиDataGridView.BackgroundColor = System.Drawing.Color.LightGoldenrodYellow
        Me.УслугиDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.УслугиDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn3, Me.Стоимость})
        Me.УслугиDataGridView.DataSource = Me.УслугиBindingSource
        Me.УслугиDataGridView.Location = New System.Drawing.Point(24, 136)
        Me.УслугиDataGridView.Name = "УслугиDataGridView"
        Me.УслугиDataGridView.Size = New System.Drawing.Size(674, 343)
        Me.УслугиDataGridView.TabIndex = 17
        '
        'ОтделенияBindingSource
        '
        Me.ОтделенияBindingSource.DataMember = "Отделения"
        Me.ОтделенияBindingSource.DataSource = Me.Gerasimova_FITDataSet
        '
        'ОтделенияTableAdapter
        '
        Me.ОтделенияTableAdapter.ClearBeforeFill = True
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "Наименование"
        Me.DataGridViewTextBoxColumn3.HeaderText = "Наименование"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'Стоимость
        '
        Me.Стоимость.DataPropertyName = "Стоимость"
        Me.Стоимость.HeaderText = "Стоимость"
        Me.Стоимость.Name = "Стоимость"
        '
        'Form3
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.LightGoldenrodYellow
        Me.ClientSize = New System.Drawing.Size(710, 561)
        Me.Controls.Add(Me.УслугиDataGridView)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label1)
        Me.Name = "Form3"
        Me.Text = "Фитнесс - клуб F.I.T"
        CType(Me.Gerasimova_FITDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.УслугиBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.УслугиDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ОтделенияBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button2 As Button
    Friend WithEvents Label4 As Label
    Friend WithEvents Label1 As Label
    Friend WithEvents Gerasimova_FITDataSet As Gerasimova_FITDataSet
    Friend WithEvents УслугиBindingSource As BindingSource
    Friend WithEvents УслугиTableAdapter As Gerasimova_FITDataSetTableAdapters.УслугиTableAdapter
    Friend WithEvents TableAdapterManager As Gerasimova_FITDataSetTableAdapters.TableAdapterManager
    Friend WithEvents ОтделенияTableAdapter As Gerasimova_FITDataSetTableAdapters.ОтделенияTableAdapter
    Friend WithEvents УслугиDataGridView As DataGridView
    Friend WithEvents ОтделенияBindingSource As BindingSource
    Friend WithEvents DataGridViewTextBoxColumn3 As DataGridViewTextBoxColumn
    Friend WithEvents Стоимость As DataGridViewTextBoxColumn
End Class
