﻿Public Class Form1
    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Close()
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        If (TextBox1.Text = "Admin" And TextBox2.Text = "Admin") Then
            Const V As String = "Выполнен вход в роли Администратора."
            MsgBox(V)
            Me.Hide()
            Form2.Show()
        ElseIf (TextBox1.Text = "Client" And TextBox2.Text = "GXi0i1tL") Then
            Const C As String = "Добро пожаловать в FIT!!!"
            MsgBox(C)
            Me.Hide()
            Form3.Show()
        Else
            Const L As String = "Авторизация не пройдена. Попробуйте снова."
            MsgBox(L)
        End If
    End Sub
End Class
