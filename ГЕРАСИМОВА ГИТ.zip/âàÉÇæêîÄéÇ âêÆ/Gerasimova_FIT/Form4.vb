﻿Public Class Form4
    Private Sub Form4_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "Gerasimova_FITDataSet.Услуги". При необходимости она может быть перемещена или удалена.
        Me.УслугиTableAdapter.Fill(Me.Gerasimova_FITDataSet.Услуги)
        'TODO: данная строка кода позволяет загрузить данные в таблицу "Gerasimova_FITDataSet.Услуги". При необходимости она может быть перемещена или удалена.
        Me.УслугиTableAdapter.Fill(Me.Gerasimova_FITDataSet.Услуги)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
        Form2.Show()
    End Sub

    Private Sub УслугиBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs)
        Me.Validate()
        Me.УслугиBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Gerasimova_FITDataSet)

    End Sub
End Class