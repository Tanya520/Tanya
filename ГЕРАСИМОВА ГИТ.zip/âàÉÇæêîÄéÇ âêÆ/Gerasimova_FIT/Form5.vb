﻿Public Class Form5
    Private Sub КлиентыBindingNavigatorSaveItem_Click(sender As Object, e As EventArgs) Handles КлиентыBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.КлиентыBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Gerasimova_FITDataSet)

    End Sub

    Private Sub Form5_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        'TODO: данная строка кода позволяет загрузить данные в таблицу "Gerasimova_FITDataSet.Клиенты". При необходимости она может быть перемещена или удалена.
        Me.КлиентыTableAdapter.Fill(Me.Gerasimova_FITDataSet.Клиенты)

    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Me.Close()
        Form2.Show()
    End Sub
End Class